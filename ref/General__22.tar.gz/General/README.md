# Mage2 Module Ktpl General

## Main Functionalities

## Attributes

 - Category - Category Image - Mobile (category_image_mobile)

